<a href="https://www.paypal.me/Bagithrcok"><img title="Support Me" src="https://img.shields.io/badge/Donate-paypal.me%2Fbagithrcok-blue"></a>
<img src="https://img.shields.io/badge/TOOLS-SENSEI-blueviolet">
<img src="https://img.shields.io/badge/SIZE-199%20KB-brightgreen"><br>
Dark-Fb No Login 100% safe
<img src="https://github.com/BOT-033/Sensei/blob/master/Screenshot_2020-07-16-00-13-54-17.jpg">
# TERMUX
```
• pkg install python2 && git -y
• pip2 install requests mechanize tqdm
• git clone https://github.com/BOT-033/Sensei
• cd Sensei
• chmod +x *
• python2 main.py
```
# Kali Linux
```
• sudo apt-get install python2 && git -y
• sudo git clone https://github.com/BOT-033/Sensei
• sudo apt-get install python3-pip
• sudo pip3 install requests mechanize tqdm
• cd Sensei
• chmod +x *
• sudo ./main.py
``` 
